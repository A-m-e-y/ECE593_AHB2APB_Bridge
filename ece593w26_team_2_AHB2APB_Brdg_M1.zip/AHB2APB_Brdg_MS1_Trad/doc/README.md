# AHB2APB_Brdg MS1 (Traditional TB)

This directory contains the documentation required for the AHB to APB Bridge - Milestone 1 (Traditional Testbench).

## Files Overview
- `README.md`: This documentation file.
- `ece593w26-DesignSpec_AHB2APB_Bridge.pdf`: Design specification for the AHB to APB Bridge.
- `VERIFICATION TEST PLAN.pdf`: Verification test plan for the design.
