# Traditional Testbench

Milestone 1
This directory contains the traditional testbench implementation for Milestone 1 of the AHB to APB Bridge project.

## Files Overview
- `README.md`: This documentation file.
- `tb_sanity_check.sv`: Traditional testbench for sanity checking the AHB to APB Bridge.    
